#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mapper.py — Mapper para WordCount en Hadoop Streaming.

Fase MAP del modelo MapReduce:
    Entrada:  líneas de texto por STDIN (un split del HDFS por tarea Map).
    Salida:   pares (palabra, 1) por STDOUT, separados por tabulador.

Cada tarea Mapper se ejecuta de forma paralela e independiente sobre un
bloque (split) del archivo de entrada. Hadoop se encarga de:
    - Leer los splits desde HDFS y enviarlos por STDIN.
    - Recoger STDOUT del proceso Mapper.
    - Realizar el shuffle & sort agrupando por clave antes del Reducer.

Autor: Yordi — Actividad Semana 10, UNIBE 2026.
"""

import sys
import re

# Expresión regular para tokenizar: capturamos secuencias de caracteres
# alfabéticos (incluye acentos y ñ del español gracias a \w con re.UNICODE).
# El flag UNICODE es el default en Python 3, así que \w cubre á, é, í, ó, ú, ñ.
TOKEN_RE = re.compile(r"\w+", re.UNICODE)


def main():
    """Lee STDIN línea a línea, tokeniza y emite pares (palabra, 1)."""
    for line in sys.stdin:
        # 1) Normalizamos: quitamos espacios en blanco extremos y pasamos
        #    todo a minúsculas para que "Casa", "casa" y "CASA" cuenten
        #    como la misma palabra.
        line = line.strip().lower()

        # 2) Si la línea queda vacía tras el strip, no aportamos nada.
        if not line:
            continue

        # 3) Extraemos todos los tokens alfanuméricos.
        #    Esto descarta puntuación (., ;, ¿, ¡, comillas, etc.) y
        #    tokens que sean solo signos (—, «, », etc.).
        for token in TOKEN_RE.findall(line):
            # 4) Filtramos números puros (opcional; se pueden dejar).
            if token.isdigit():
                continue

            # 5) Emitimos por STDOUT en el formato clave\tvalor esperado
            #    por Hadoop Streaming. El '1' es un contador que el
            #    Reducer sumará por clave.
            print(f"{token}\t1")


if __name__ == "__main__":
    main()
