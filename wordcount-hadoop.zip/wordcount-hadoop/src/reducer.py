#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
reducer.py — Reducer para WordCount en Hadoop Streaming.

Fase REDUCE del modelo MapReduce:
    Entrada:  pares (palabra, 1) ORDENADOS por clave, por STDIN.
    Salida:   pares (palabra, total) por STDOUT.

Un dato clave de Hadoop Streaming: el framework garantiza que TODOS los
valores para una misma clave llegan al mismo Reducer, y además llegan
CONTIGUOS y ORDENADOS. Eso nos permite acumular con una sola variable
en memoria en lugar de un diccionario, lo cual es crítico cuando el
vocabulario es enorme.

Autor: Yordi — Actividad Semana 10, UNIBE 2026.
"""

import sys


def main():
    """Agrega los conteos por palabra aprovechando el orden del shuffle."""
    current_word = None    # Palabra que estamos acumulando actualmente.
    current_count = 0      # Contador parcial para current_word.

    for line in sys.stdin:
        # 1) Parseamos la línea "palabra\tvalor" que produjo el Mapper
        #    (o el Combiner, si está activo).
        line = line.strip()
        if not line:
            continue

        try:
            word, count = line.split("\t", 1)
            count = int(count)
        except ValueError:
            # Línea malformada: la ignoramos para no romper el job.
            continue

        # 2) Como los pares vienen ORDENADOS por clave, si la palabra
        #    actual sigue siendo la misma, simplemente acumulamos.
        if word == current_word:
            current_count += count
        else:
            # 3) Cambió la clave: emitimos el total de la palabra anterior
            #    (si existía) y reiniciamos el acumulador.
            if current_word is not None:
                print(f"{current_word}\t{current_count}")
            current_word = word
            current_count = count

    # 4) Al final del stream, emitimos la última palabra pendiente.
    if current_word is not None:
        print(f"{current_word}\t{current_count}")


if __name__ == "__main__":
    main()
