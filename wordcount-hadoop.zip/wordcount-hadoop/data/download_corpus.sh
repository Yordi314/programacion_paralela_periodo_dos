#!/usr/bin/env bash
# download_corpus.sh — Descarga un corpus de obras clásicas en español
# de dominio público desde Project Gutenberg. Se usan como dataset
# de prueba para el WordCount.
#
# Uso:
#   bash data/download_corpus.sh

set -euo pipefail

CORPUS_DIR="data/corpus"
mkdir -p "${CORPUS_DIR}"

echo "=== Descargando corpus de Project Gutenberg (~3 MB total) ==="

# Don Quijote de la Mancha (Cervantes) — ~2.3 MB
curl -sSL -o "${CORPUS_DIR}/quijote.txt"    "https://www.gutenberg.org/cache/epub/2000/pg2000.txt"

# Novelas Ejemplares (Cervantes) — ~1 MB
curl -sSL -o "${CORPUS_DIR}/novelas.txt"    "https://www.gutenberg.org/cache/epub/26224/pg26224.txt"

# La Regenta (Clarín) — ~1.4 MB
curl -sSL -o "${CORPUS_DIR}/regenta.txt"    "https://www.gutenberg.org/cache/epub/17073/pg17073.txt"

echo ""
echo "=== Corpus descargado ==="
ls -lh "${CORPUS_DIR}"
echo ""
wc -w "${CORPUS_DIR}"/*.txt
