#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
convert_pdf.py — Utilitario para convertir PDFs a texto plano (.txt)
y dejarlos listos para ser subidos a HDFS como corpus del WordCount.

Uso:
    python3 scripts/convert_pdf.py <ruta_pdf1> [<ruta_pdf2> ...]
    python3 scripts/convert_pdf.py data/pdfs/*.pdf

Salida:
    Los .txt se escriben en data/corpus/ con el mismo nombre base.

Requiere:
    pip install pdfplumber
"""
import sys
import os
from pathlib import Path

try:
    import pdfplumber
except ImportError:
    print("Falta la dependencia. Instala con: pip install pdfplumber")
    sys.exit(1)

OUT_DIR = Path("data/corpus")


def pdf_to_txt(pdf_path: Path) -> Path:
    """Extrae el texto de todas las páginas y lo guarda como .txt."""
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    txt_path = OUT_DIR / (pdf_path.stem + ".txt")

    with pdfplumber.open(pdf_path) as pdf, txt_path.open("w", encoding="utf-8") as out:
        for page in pdf.pages:
            text = page.extract_text() or ""
            out.write(text)
            out.write("\n")

    return txt_path


def main():
    if len(sys.argv) < 2:
        print("Uso: python3 convert_pdf.py <archivo.pdf> [...]")
        sys.exit(1)

    for arg in sys.argv[1:]:
        pdf_path = Path(arg)
        if not pdf_path.exists():
            print(f"[SKIP] No existe: {pdf_path}")
            continue

        print(f"Convirtiendo {pdf_path.name} ...")
        out = pdf_to_txt(pdf_path)
        size_kb = os.path.getsize(out) / 1024
        print(f"    -> {out}  ({size_kb:.1f} KB)")


if __name__ == "__main__":
    main()
