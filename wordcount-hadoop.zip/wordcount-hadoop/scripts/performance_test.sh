#!/usr/bin/env bash
# performance_test.sh — Ejecuta el job WordCount con 1, 2 y 4 reducers
# y genera un resumen comparativo de tiempos.
#
# Uso (desde el contenedor):
#   bash /wc/scripts/performance_test.sh

set -euo pipefail

PROJECT_DIR="/wc"
RESULTS_FILE="${PROJECT_DIR}/output_sample/performance_summary.csv"

echo "num_reducers,tiempo_segundos,archivos_output" > "${RESULTS_FILE}"

for N in 1 2 4; do
  echo ""
  echo "############################################################"
  echo "### CORRIDA CON ${N} REDUCERS"
  echo "############################################################"

  START=$(date +%s)
  bash "${PROJECT_DIR}/scripts/run_hadoop.sh" "${N}"
  END=$(date +%s)

  ELAPSED=$((END - START))
  NUM_PARTS=$(hdfs dfs -ls "/user/wordcount/output-r${N}/part-*" | wc -l)

  echo "${N},${ELAPSED},${NUM_PARTS}" >> "${RESULTS_FILE}"
done

echo ""
echo "=== RESUMEN COMPARATIVO ==="
cat "${RESULTS_FILE}" | column -t -s ','
