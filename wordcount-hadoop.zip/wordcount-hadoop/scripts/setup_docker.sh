#!/usr/bin/env bash
# setup_docker.sh — Levanta un clúster Hadoop de un solo nodo (pseudo-distribuido)
# usando la imagen oficial de Apache Hadoop. Esta es la forma más rápida y
# reproducible de tener HDFS + YARN corriendo en tu máquina.
#
# Uso:
#   bash scripts/setup_docker.sh
#
# Requisitos:
#   - Docker Desktop instalado y corriendo.
#   - ~2 GB de RAM libres para el contenedor.

set -euo pipefail

CONTAINER_NAME="hadoop-wordcount"
IMAGE="apache/hadoop:3.3.6"

echo "=== [1/4] Verificando Docker ==="
if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: Docker no está instalado. Instálalo desde https://www.docker.com/products/docker-desktop"
  exit 1
fi

echo "=== [2/4] Descargando imagen ${IMAGE} (una sola vez) ==="
docker pull "${IMAGE}"

echo "=== [3/4] Levantando contenedor ${CONTAINER_NAME} ==="
# Si ya existe, lo eliminamos para arrancar limpio.
docker rm -f "${CONTAINER_NAME}" >/dev/null 2>&1 || true

# Montamos el directorio del proyecto dentro del contenedor para poder
# subir el mapper/reducer y el corpus a HDFS desde adentro.
docker run -d \
  --name "${CONTAINER_NAME}" \
  -p 9870:9870 \
  -p 8088:8088 \
  -v "$(pwd):/wc" \
  "${IMAGE}" \
  bash -c "hdfs namenode -format -force && \
           hdfs --daemon start namenode && \
           hdfs --daemon start datanode && \
           yarn --daemon start resourcemanager && \
           yarn --daemon start nodemanager && \
           tail -f /dev/null"

echo "=== [4/4] Esperando a que HDFS quede disponible ==="
sleep 15

echo ""
echo "Listo. UIs disponibles en:"
echo "  - NameNode:        http://localhost:9870"
echo "  - ResourceManager: http://localhost:8088"
echo ""
echo "Para entrar al contenedor:"
echo "  docker exec -it ${CONTAINER_NAME} bash"
