#!/usr/bin/env bash
# run_local_test.sh — Prueba mapper.py y reducer.py con UNIX pipes,
# SIN Hadoop. Es la forma canónica de validar el código antes de
# desplegarlo en el clúster.
#
# Emula el flujo completo:
#   cat archivo | mapper | sort | reducer
#
# El `sort` intermedio replica lo que Hadoop hace en la fase shuffle:
# garantizar que todas las ocurrencias de una misma palabra lleguen
# contiguas al reducer.
#
# Uso:
#   bash scripts/run_local_test.sh data/corpus/*.txt

set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "Uso: $0 <archivo1.txt> [archivo2.txt ...]"
  exit 1
fi

echo "=== Ejecutando pipeline local: mapper → sort → reducer ==="
echo "Archivos de entrada: $*"
echo ""

cat "$@" \
  | python3 src/mapper.py \
  | sort \
  | python3 src/reducer.py \
  | sort -k2 -nr \
  | head -30

echo ""
echo "=== Top 30 palabras más frecuentes mostradas arriba ==="
