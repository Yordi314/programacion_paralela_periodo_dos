#!/usr/bin/env bash
# run_hadoop.sh — Ejecuta el job WordCount en el clúster Hadoop
# usando Hadoop Streaming (permite mapper/reducer en Python).
#
# Este script se ejecuta DENTRO del contenedor levantado por
# setup_docker.sh. El directorio del proyecto está montado en /wc.
#
# Uso (desde el contenedor):
#   bash /wc/scripts/run_hadoop.sh [num_reducers]
#
# Argumentos:
#   num_reducers — cantidad de tareas Reduce (default: 1)

set -euo pipefail

NUM_REDUCERS="${1:-1}"
PROJECT_DIR="/wc"
STREAMING_JAR=$(find /opt/hadoop -name "hadoop-streaming-*.jar" | head -1)

HDFS_INPUT="/user/wordcount/input"
HDFS_OUTPUT="/user/wordcount/output-r${NUM_REDUCERS}"

echo "=== [1/5] Verificando Hadoop Streaming JAR ==="
if [ -z "${STREAMING_JAR}" ]; then
  echo "ERROR: No se encontró hadoop-streaming-*.jar"
  exit 1
fi
echo "JAR encontrado: ${STREAMING_JAR}"

echo "=== [2/5] Preparando HDFS ==="
hdfs dfs -mkdir -p "${HDFS_INPUT}"
# Limpiamos salidas previas (Hadoop falla si el directorio ya existe)
hdfs dfs -rm -r -f "${HDFS_OUTPUT}" || true

echo "=== [3/5] Subiendo corpus a HDFS ==="
# -f fuerza la sobrescritura si ya existían los archivos.
hdfs dfs -put -f "${PROJECT_DIR}/data/corpus/"*.txt "${HDFS_INPUT}/"
echo "Archivos en HDFS:"
hdfs dfs -ls "${HDFS_INPUT}"

echo "=== [4/5] Lanzando job MapReduce con ${NUM_REDUCERS} reducers ==="
START_TIME=$(date +%s)

hadoop jar "${STREAMING_JAR}" \
    -D mapreduce.job.name="WordCount-Yordi-r${NUM_REDUCERS}" \
    -D mapreduce.job.reduces="${NUM_REDUCERS}" \
    -files "${PROJECT_DIR}/src/mapper.py,${PROJECT_DIR}/src/reducer.py" \
    -input  "${HDFS_INPUT}" \
    -output "${HDFS_OUTPUT}" \
    -mapper  "python3 mapper.py" \
    -reducer "python3 reducer.py" \
    -combiner "python3 reducer.py"

END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))

echo "=== [5/5] Resultado ==="
echo "Tiempo total: ${ELAPSED} segundos"
echo ""
echo "Archivos de salida en HDFS:"
hdfs dfs -ls "${HDFS_OUTPUT}"
echo ""
echo "Top 20 palabras más frecuentes:"
hdfs dfs -cat "${HDFS_OUTPUT}/part-*" | sort -k2 -nr | head -20

# Guardamos también una copia local del output para el informe.
LOCAL_OUT="${PROJECT_DIR}/output_sample/hadoop-r${NUM_REDUCERS}"
mkdir -p "${LOCAL_OUT}"
hdfs dfs -get -f "${HDFS_OUTPUT}/part-*" "${LOCAL_OUT}/"
echo ""
echo "Copia local guardada en: ${LOCAL_OUT}"
echo "Duración del job: ${ELAPSED}s" > "${LOCAL_OUT}/timing.txt"
