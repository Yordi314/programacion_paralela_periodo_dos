# WordCount con el Modelo MapReduce

**Actividad Semana 10 — Big Data**
Universidad Iberoamericana (UNIBE) · 2026
Autor: **Yordi**

Implementación completa del algoritmo WordCount basado en el modelo MapReduce,
incluyendo:

1. **Mapper y Reducer en Python** compatibles con Hadoop Streaming (portable a un clúster real).
2. **Runtime propio en Python** que emula fielmente las cinco fases de Hadoop (input splits, map paralelo, hash-partition, shuffle+sort, reduce paralelo) usando `multiprocessing` para paralelismo real.

## Estructura

```
wordcount-hadoop/
├── README.md
├── src/
│   ├── mapper.py                   ← Fase Map (compatible con Hadoop Streaming)
│   ├── reducer.py                  ← Fase Reduce (compatible con Hadoop Streaming)
│   └── mapreduce_runner.py         ← Runtime que ejecuta las 5 fases en paralelo
├── scripts/
│   ├── run_local_test.sh           ← Prueba mapper+reducer con UNIX pipes
│   ├── run_all_experiments.sh      ← Corridas comparativas (varía reducers/combiner)
│   ├── run_hadoop.sh               ← [Referencia] Ejecución en un clúster Hadoop real
│   ├── setup_docker.sh             ← [Referencia] Setup de Hadoop en Docker
│   └── convert_pdf.py              ← Utilitario para convertir PDFs → texto
├── data/
│   ├── download_corpus.sh          ← Descarga corpus de Project Gutenberg
│   └── corpus/                     ← Archivos .txt de entrada
├── output_sample/                  ← Resultados de las corridas
└── docs/
    └── informe.docx                ← Informe formal UNIBE
```

## Cómo ejecutar

### 1. Descargar el corpus

```bash
bash data/download_corpus.sh
```

Baja ~4.7 MB de textos clásicos en español (Don Quijote, Novelas Ejemplares, La Regenta).

### 2. Correr el job MapReduce

```bash
python3 src/mapreduce_runner.py \
    --input data/corpus \
    --output output_sample/output-m4-r2-c1 \
    --mappers 4 \
    --reducers 2 \
    --combiner
```

Verás las 5 fases en tiempo real y al final el resumen con tiempos por fase.

### 3. Ver los resultados

```bash
ls output_sample/output-m4-r2-c1/
# _SUCCESS  part-r-00000  part-r-00001

# Top 10 palabras más frecuentes (combinando particiones):
cat output_sample/output-m4-r2-c1/part-r-* | sort -k2 -nr | head -10
```

### 4. Ejecutar la comparativa de rendimiento

```bash
bash scripts/run_all_experiments.sh
```

Corre el job 4 veces variando reducers (1, 2, 4) y con/sin combiner. Guarda todo en `output_sample/performance_summary.csv`.

## Flujo del runtime

```
splits(corpus, N)
      ↓
[mapper × N] ──── multiprocessing.Pool ──── (opcional) combiner
      ↓
partition(key) = md5(key) mod R
      ↓
shuffle + sort por clave
      ↓
[reducer × R] ──── multiprocessing.Pool
      ↓
_SUCCESS + part-r-00000 ... part-r-(R-1)
```

## Compatibilidad con Hadoop real

`src/mapper.py` y `src/reducer.py` siguen el contrato de Hadoop Streaming (STDIN → STDOUT, formato `clave\tvalor`). El script `scripts/run_hadoop.sh` los ejecuta sin modificación en un clúster Hadoop mediante `hadoop jar hadoop-streaming.jar`.

## Referencias

- Dean, J. & Ghemawat, S. (2008). MapReduce: Simplified Data Processing on Large Clusters. CACM 51(1).
- Apache Hadoop MapReduce Tutorial. https://hadoop.apache.org/docs/current/hadoop-mapreduce-client/hadoop-mapreduce-client-core/MapReduceTutorial.html
- White, T. (2015). Hadoop: The Definitive Guide (4ª ed.). O'Reilly.
